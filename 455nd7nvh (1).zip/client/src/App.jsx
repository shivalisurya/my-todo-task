
import { useState } from "react";
import "./App.css";

function App() {
  const [task, setTask] = useState("");
  const [tasks, setTasks] = useState([]);

  function addTask() {
    if (task.trim() === "") return;

    setTasks([
      ...tasks,
      {
        id: Date.now(),
        text: task.trim(),
        completed: false,
      },
    ]);

    setTask("");
  }

  function toggleTask(id) {
    setTasks(
      tasks.map((item) =>
        item.id === id
          ? { ...item, completed: !item.completed }
          : item
      )
    );
  }

  function deleteTask(id) {
    setTasks(tasks.filter((item) => item.id !== id));
  }

  return (
    <div className="App">
      <h1>My Todo Manager</h1>

      <div className="task-form">
        <input
          type="text"
          placeholder="Enter your task..."
          value={task}
          onChange={(e) => setTask(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") addTask();
          }}
        />

        <button onClick={addTask}>Add Task</button>
      </div>

      <div className="task-list">
        <h2>My Tasks ({tasks.length})</h2>

        {tasks.length === 0 ? (
          <p>No tasks yet. Add your first task!</p>
        ) : (
          tasks.map((item) => (
            <div className="task-item" key={item.id}>
              <span
                onClick={() => toggleTask(item.id)}
                style={{
                  textDecoration: item.completed
                    ? "line-through"
                    : "none",
                  cursor: "pointer",
                  flex: 1,
                }}
              >
                {item.completed ? "✅ " : "⬜ "}
                {item.text}
              </span>

              <button onClick={() => deleteTask(item.id)}>
                Delete
              </button>
            </div>
          ))
        )}
      </div>

      <section className="assessment-plan">
        <h2>📚 Project Assessment Plan</h2>

        <p>
          Track the development stages of your Todo Task Manager.
        </p>

        <div className="plan-item">
          <h3>1. Planning and Design</h3>
          <p>Define project objectives and design the interface.</p>
        </div>

        <div className="plan-item">
          <h3>2. Frontend Development</h3>
          <p>Create the task form, task list, and user interface.</p>
        </div>

        <div className="plan-item">
          <h3>3. Backend Development</h3>
          <p>Develop APIs using Node.js and Express.js.</p>
        </div>

        <div className="plan-item">
          <h3>4. Database Connectivity</h3>
          <p>Connect MongoDB to store and manage tasks.</p>
        </div>

        <div className="plan-item">
          <h3>5. Testing and Evaluation</h3>
          <p>Test adding, completing, and deleting tasks.</p>
        </div>

        <div className="plan-item">
          <h3>6. Final Demonstration</h3>
          <p>Verify the application and prepare the presentation.</p>
        </div>
      </section>
    </div>
  );
}

export default App;
